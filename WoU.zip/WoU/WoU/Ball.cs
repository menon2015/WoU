﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace WoU
{
    internal class Ball
    {
        double r;
        public double x;
        public double y;
        public double z;
        public Color color;
        public bool drag = false;

        public Ball(double r, double x, double y, double z, Color color)
        {
            this.r = r;
            this.x = x;
            this.y = y;
            this.z = z;
            this.color = color;
        }

        public bool CheckIfIN(double thatX, double thatY)
        {
            double distx = thatX - x;
            double disty = thatY - y;
            if (Math.Sqrt((distx * distx) + (disty * disty)) < r)
            {
                return true;
            }
            return false;
        }
        public double AngleCosFinder(double xp, double yp,Sun sun)
        {
            double zp = Math.Sqrt(r*r-Math.Pow((xp-x),2)-Math.Pow((yp-y),2))+z;
            double v1x = (xp - x);
            double v1y = (yp - y);
            double v1z = (zp - z);
            double v2x = (sun.x - xp);
            double v2y = (sun.y - yp);
            double v2z = (sun.z - zp);
            double angleCos = (v1x*v2x+ v1y*v2y + v1z*v2z)/(Math.Sqrt(v1x*v1x+v1y*v1y+v1z*v1z)*Math.Sqrt(v2x*v2x+v2y*v2y+v2z*v2z));
            return Math.Max(angleCos,0);
        }
    }
}
