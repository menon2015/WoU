﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WoU
{
    public partial class Form1 : Form
    {
        Bitmap bmp = new Bitmap(10, 10);
        List<Ball> ballZ = new List<Ball>();
        List<Sun> sunZ = new List<Sun>();
        int BallZCount = 4;
        int SunCount = 1;
        Random rnd = new Random();
        double bfilter = 0;
        public Form1()
        {
            InitializeComponent();
           
            for (int i = 0; i < SunCount; i++)
            {
                int red = rnd.Next(0, byte.MaxValue + 1);
                int green = rnd.Next(0, byte.MaxValue + 1);
                int blue = rnd.Next(0, byte.MaxValue + 1);
                sunZ.Add(new Sun(rnd.Next(0,pictureBox1.Width), rnd.Next(0,pictureBox1.Height),500, Color.FromArgb(red, green, blue)));

            }
        }
        private List<Ball> Zsort(List<Ball> balls)
        {
            List<Ball> new_balls = new List<Ball>();
            try
            {
                for (int j = 0; j < BallZCount; j++)
                {


                    double furthest = balls[0].z;
                    int furthestBall = 0;
                    for (int i = 0; i < balls.Count; i++)
                    {
                        if (balls[i].z > furthest)
                        {
                            furthest = balls[i].z;
                            furthestBall = i;
                        }
                    }
                    new_balls.Add(balls[furthestBall]);
                    balls.RemoveAt(furthestBall);
                }
            }
            catch { };
            return new_balls;
        }

        private void Generate()
        {
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);

            for (int x = 0; x < bmp.Width; x++)
            {
                for (int y = 0; y < bmp.Height; y++)
                {
                    foreach (Ball ball in ballZ)
                    {
                        if (ball.CheckIfIN(x, y))
                        {
                            double colorModifier = ball.AngleCosFinder(x, y, sunZ[0]);
                            int red = Convert.ToInt32(Math.Max(Math.Min(ball.color.R * colorModifier+bfilter, 255),0));
                            int green = Convert.ToInt32(Math.Max(Math.Min(ball.color.G * colorModifier+bfilter, 255),0));
                            int blue = Convert.ToInt32(Math.Max(Math.Min(ball.color.B * colorModifier+bfilter, 255),0));
                            Color pColor = Color.FromArgb(red, green,blue);
                            bmp.SetPixel(x, y, pColor);
                        }
                    }
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            ballZ.Clear();
             for (int i = 0; i < BallZCount; i++)
            {
                int red = rnd.Next(0, byte.MaxValue + 1);
                int green = rnd.Next(0, byte.MaxValue + 1);
                int blue = rnd.Next(0, byte.MaxValue + 1);
               ballZ.Add(new Ball(rnd.Next(0, 100), rnd.Next(0, pictureBox1.Width), rnd.Next(0, pictureBox1.Height), 0, Color.FromArgb(red, green, blue)));
            }
            ballZ = Zsort(ballZ);
            Generate();

            pictureBox1.Refresh();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            g.DrawImage(bmp,0,0);
        }

        private void pictureBox1_DoubleClick(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            for(int i = 0; i < BallZCount; i++)
            {
                if (ballZ[i].CheckIfIN(e.X, e.Y))
                {
                    ballZ[i].drag = true;
                    ballZ[i].x = e.X;
                    ballZ[i].y = e.Y;
                }
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (ballZ.Count != 0)
            {
                for (int i = 0; i < BallZCount; i++)
                {
                    if (ballZ[i].drag)
                    {
                        ballZ[i].x = e.X;
                        ballZ[i].y = e.Y;
                    }
                }
                Generate();
                pictureBox1.Refresh();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            bfilter = trackBar1.Value;
            Generate();
            pictureBox1.Refresh();
        }
    }
}
