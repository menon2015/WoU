﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoU
{
    internal class Sun
    {
        public double x;
        public double y;
        public double z;
        public Color color;

        public Sun(double x, double y, double z, Color color)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.color = color;
        }
    }
}
