﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace billardooo_2_lol
{
    internal class Ball
    {
        public double r = 30;
        public double x;
        public double y;
        public double vx;
        public double vy;
        double drag = 0.01;
        int table_height;
        int table_width;
        public bool ball_click;
        public bool cooldown = false;
        Brush brush;

        public Ball(int table_height , int table_width, double x, double y , double vx, double vy, SolidBrush brush)
        {
            this.table_height = table_height;
            this.table_width = table_width;
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.brush = brush;

        }


        public void roll()
        {
            x += vx;
            y += vy;

           if (vx > 0 )
            {
                vx -= drag * vx;
            }

            if (vy > 0)
            {
                vy -= drag * vy;
            }

            if (vx < 0)
            {
                vx -= drag * vx;
            }

            if (vy < 0)
            {
                vy -= drag * vy;
            }


        }

        public void ball_bounce_check()
        {
            if (x <= r || (int)x >= table_width - (int)r )
            {
                vx = vx * (-1);
            }
            if (y <= r || (int)y >= table_height - (int)r)
            {
                vy = vy * (-1);
            }
        }
        
        public void ball_click_two(int click2x,int click2y)
        {
            vx += (x-click2x)/10;
            vy += (y-click2y)/10;
            ball_click = false;
        }

        public void ball_hit(double newvx , double newvy )
        {
            vx = newvx;
            vy = newvy;
        }
 
        public void Draw(Graphics g)
        {

            if (ball_click)
            {
                Brush brush1 = new SolidBrush(Color.OrangeRed);
                g.FillEllipse(brush1, (int)x, (int)y, (int)r, (int)r);

            }
            else
            {
                g.FillEllipse(brush, (int)x, (int)y, (int)r, (int)r);
            }
        }

    }
}
